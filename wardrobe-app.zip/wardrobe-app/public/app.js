const CATEGORIES = {
  top: 'Верх', bottom: 'Низ', dress: 'Платья', outerwear: 'Верхняя одежда',
  shoes: 'Обувь', accessory: 'Аксессуары',
};
const SEASONS = { all: 'Всесезонная', spring: 'Весна', summer: 'Лето', autumn: 'Осень', winter: 'Зима' };
const COLORS = {
  черный: '#111', белый: '#fff', серый: '#9a9a9a', бежевый: '#d9c5a0', коричневый: '#7a5230',
  синий: '#2a4bb5', голубой: '#8cc4ee', зеленый: '#3a8a4f', красный: '#c42b2b', розовый: '#f0a0b8',
  желтый: '#f0d23a', фиолетовый: '#7c4bb0', оранжевый: '#ee8a2b',
};

const $ = (s) => document.querySelector(s);
const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  kids.flat().forEach((k) => n.append(k));
  return n;
};

let items = [];
let activeCategory = '';
let editingId = null;
let photoFile = null;

async function api(url, opts) {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Что-то пошло не так');
  return data;
}

/* ---------- Вкладки ---------- */
document.querySelectorAll('.tabs button').forEach((b) =>
  b.addEventListener('click', () => {
    document.querySelectorAll('.tabs button').forEach((x) => x.setAttribute('aria-selected', x === b));
    document.querySelectorAll('.panel').forEach((p) => (p.hidden = p.id !== 'tab-' + b.dataset.tab));
    if (b.dataset.tab === 'outfits') loadOutfits();
    if (b.dataset.tab === 'trends' && !$('#trendList').children.length) loadTrends();
  })
);

/* ---------- Вещи ---------- */
function renderChips() {
  const box = $('#categoryChips');
  box.replaceChildren();
  const all = { '': 'Все', ...CATEGORIES };
  for (const [key, label] of Object.entries(all)) {
    const b = el('button', { className: 'chip', type: 'button', textContent: label });
    b.setAttribute('aria-pressed', key === activeCategory);
    b.addEventListener('click', () => { activeCategory = key; renderChips(); loadItems(); });
    box.append(b);
  }
}

async function loadItems() {
  const params = new URLSearchParams();
  if (activeCategory) params.set('category', activeCategory);
  if ($('#itemSearch').value.trim()) params.set('q', $('#itemSearch').value.trim());
  items = await api('/api/items?' + params);
  const grid = $('#itemGrid');
  grid.replaceChildren();
  $('#itemEmpty').hidden = items.length > 0;
  for (const it of items) {
    const card = el('button', { className: 'card', type: 'button' },
      el('img', { src: it.image, alt: it.name, loading: 'lazy' }),
      el('div', { className: 'meta' },
        el('div', { className: 'name', textContent: it.name }),
        el('div', { className: 'sub' },
          it.color ? el('span', { className: 'dot', style: `background:${COLORS[it.color] || '#ccc'}` }) : '',
          [CATEGORIES[it.category], it.color].filter(Boolean).join(', '))));
    card.addEventListener('click', () => openView(it));
    grid.append(card);
  }
}

let searchTimer;
$('#itemSearch').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadItems, 250);
});

/* ---------- Просмотр вещи ---------- */
function shopQuery(it) {
  return [it.color, it.name, it.brand].filter(Boolean).join(' ');
}

function openView(it) {
  const body = $('#viewBody');
  const rows = [
    ['Категория', CATEGORIES[it.category]], ['Сезон', SEASONS[it.season]],
    ['Цвет', it.color], ['Бренд', it.brand], ['Заметки', it.notes],
  ].filter(([, v]) => v);
  body.replaceChildren(
    el('h2', { textContent: it.name }),
    el('img', { src: it.image, alt: it.name }),
    el('dl', {}, rows.flatMap(([k, v]) => [el('dt', { textContent: k }), el('dd', { textContent: v })])),
    el('div', { className: 'view-actions' },
      Object.assign(el('button', { className: 'btn primary', textContent: 'Найти похожее в магазинах' }),
        { onclick: () => { $('#viewDialog').close(); openShop(shopQuery(it)); } }),
      Object.assign(el('button', { className: 'btn', textContent: 'Изменить' }),
        { onclick: () => { $('#viewDialog').close(); openForm(it); } }),
      Object.assign(el('button', { className: 'btn danger', textContent: 'Удалить' }),
        { onclick: async () => {
            if (!confirm('Удалить «' + it.name + '»?')) return;
            await api('/api/items/' + it.id, { method: 'DELETE' });
            $('#viewDialog').close();
            loadItems();
          } }),
      Object.assign(el('button', { className: 'btn', textContent: 'Закрыть' }),
        { onclick: () => $('#viewDialog').close() })));
  $('#viewDialog').showModal();
}

/* ---------- Форма вещи ---------- */
const form = $('#itemForm');

// Уменьшаем фото до 1280 px по длинной стороне, чтобы быстро загружалось с телефона
function downscale(file, max = 1280) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => resolve(b ? new File([b], 'photo.jpg', { type: 'image/jpeg' }) : file), 'image/jpeg', 0.85);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
  });
}

function openForm(it = null) {
  editingId = it ? it.id : null;
  photoFile = null;
  form.reset();
  $('#dialogTitle').textContent = it ? 'Изменить вещь' : 'Новая вещь';
  $('#formError').hidden = true;
  const prev = $('#photoPreview');
  if (it) {
    for (const k of ['name', 'category', 'season', 'color', 'brand', 'notes']) form.elements[k].value = it[k];
    prev.src = it.image; prev.hidden = false; $('#photoHint').hidden = true;
  } else {
    prev.hidden = true; $('#photoHint').hidden = false;
  }
  $('#photoBox').style.display = it ? 'none' : '';
  $('#itemDialog').showModal();
}

$('#addBtn').addEventListener('click', () => openForm());
$('#cancelBtn').addEventListener('click', () => $('#itemDialog').close());

$('#photoInput').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  photoFile = await downscale(f);
  const prev = $('#photoPreview');
  prev.src = URL.createObjectURL(photoFile);
  prev.hidden = false;
  $('#photoHint').hidden = true;
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#formError');
  err.hidden = true;
  const fd = new FormData(form);
  const btn = $('#saveBtn');
  try {
    btn.disabled = true;
    if (editingId) {
      await api('/api/items/' + editingId, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(fd)),
      });
    } else {
      if (!photoFile) throw new Error('Добавьте фото вещи');
      fd.delete('photo');
      fd.append('photo', photoFile);
      await api('/api/items', { method: 'POST', body: fd });
    }
    $('#itemDialog').close();
    loadItems();
  } catch (ex) {
    err.textContent = ex.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
  }
});

/* ---------- Образы ---------- */
async function loadOutfits() {
  const list = $('#outfitList');
  const data = await api('/api/outfits?season=' + $('#outfitSeason').value);
  list.replaceChildren();
  $('#outfitEmpty').hidden = data.length > 0;
  data.forEach((o, i) => {
    list.append(el('article', { className: 'outfit' },
      el('h3', { textContent: 'Образ ' + (i + 1) },),
      el('div', { className: 'strip' }, o.items.map((it) => {
        const img = el('img', { src: it.image, alt: it.name, loading: 'lazy' });
        img.addEventListener('click', () => openView(it));
        return el('figure', {}, img, el('figcaption', { textContent: it.name }));
      }))));
  });
}
$('#outfitSeason').addEventListener('change', loadOutfits);
$('#outfitRefresh').addEventListener('click', loadOutfits);

/* ---------- Тренды ---------- */
async function loadTrends() {
  const q = $('#trendQuery').value.trim();
  const list = $('#trendList');
  list.replaceChildren(el('p', { className: 'note', textContent: 'Ищу…' }));
  try {
    const data = await api('/api/trends?q=' + encodeURIComponent(q));
    $('#trendNote').hidden = !data.note;
    $('#trendNote').textContent = data.note || '';
    list.replaceChildren();
    if (!data.results.length) {
      list.append(el('p', { className: 'empty', textContent: 'Ничего не нашлось. Попробуйте другой запрос.' }));
    }
    for (const t of data.results) {
      const shopBtn = el('button', { className: 'btn primary', textContent: 'Где купить' });
      shopBtn.addEventListener('click', () => openShop(t.title.replace(/\s[-|–—].*$/, '')));
      const go = el('div', { className: 'go' }, shopBtn);
      if (t.link) go.append(el('a', { href: t.link, target: '_blank', rel: 'noopener noreferrer', textContent: 'Читать' }));
      list.append(el('article', { className: 'trend' },
        el('div', {}, el('h3', { textContent: t.title }),
          el('p', { textContent: t.snippet || t.source || '' })), go));
    }
  } catch (ex) {
    list.replaceChildren(el('p', { className: 'error', textContent: ex.message }));
  }
}
$('#trendForm').addEventListener('submit', (e) => { e.preventDefault(); loadTrends(); });

/* ---------- Где купить ---------- */
async function openShop(query) {
  $('#shopTitle').textContent = 'Где купить: ' + query;
  const list = $('#shopList');
  list.replaceChildren(el('p', { className: 'note', textContent: 'Ищу…' }));
  $('#shopNote').hidden = true;
  $('#shopDialog').showModal();
  try {
    const data = await api('/api/shop?q=' + encodeURIComponent(query));
    $('#shopNote').hidden = !data.note;
    $('#shopNote').textContent = data.note || '';
    list.replaceChildren();
    if (!data.results.length) list.append(el('p', { className: 'empty', textContent: 'Ничего не нашлось.' }));
    for (const r of data.results) {
      const a = el('a', { href: r.link, target: '_blank', rel: 'noopener noreferrer', textContent: 'Открыть' });
      list.append(el('div', { className: 'shop-item' },
        r.thumbnail ? el('img', { src: r.thumbnail, alt: '' }) : '',
        el('div', { className: 'info' },
          el('h3', { textContent: r.title }),
          el('p', {}, r.price ? el('span', { className: 'price', textContent: r.price + ' · ' }) : '', r.source || '')),
        a));
    }
  } catch (ex) {
    list.replaceChildren(el('p', { className: 'error', textContent: ex.message }));
  }
}
$('#shopClose').addEventListener('click', () => $('#shopDialog').close());

/* ---------- Старт ---------- */
renderChips();
loadItems();

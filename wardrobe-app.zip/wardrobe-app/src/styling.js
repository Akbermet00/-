// Простой стилист: собирает образы из вещей гардероба по правилам сочетания цветов и сезона.

const NEUTRAL = new Set(['черный', 'белый', 'серый', 'бежевый', 'коричневый']);
const SOFT = new Set(['синий', 'голубой']); // деним и близкие — сочетаются почти со всем

const SEASON_NEEDS_OUTERWEAR = { winter: true, autumn: true, spring: false, summer: false };

function fitsSeason(item, season) {
  return item.season === 'all' || !season || season === 'all' || item.season === season;
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function colorScore(items) {
  const bright = new Set(
    items.map((i) => i.color).filter((c) => c && !NEUTRAL.has(c) && !SOFT.has(c))
  );
  let score = 0;
  if (bright.size === 0) score += 3;
  else if (bright.size === 1) score += 2;
  else if (bright.size === 2) score -= 1;
  else score -= 4;

  const top = items.find((i) => i.category === 'top' || i.category === 'dress');
  const bottom = items.find((i) => i.category === 'bottom');
  if (top && bottom && top.color && top.color === bottom.color && !NEUTRAL.has(top.color)) score -= 2;
  return score;
}

function generateOutfits(items, { season = 'all', limit = 6 } = {}) {
  const pool = items.filter((i) => fitsSeason(i, season));
  const by = (c) => pool.filter((i) => i.category === c);
  const tops = by('top');
  const bottoms = by('bottom');
  const dresses = by('dress');
  const outer = by('outerwear');
  const shoes = by('shoes');
  const acc = by('accessory');

  const bases = [];
  for (const t of tops) for (const b of bottoms) bases.push([t, b]);
  for (const d of dresses) bases.push([d]);

  const needOuter = SEASON_NEEDS_OUTERWEAR[season];
  const seen = new Set();
  const result = [];

  for (const base of bases) {
    const parts = [...base];
    if (shoes.length) parts.push(pick(shoes));
    if (outer.length && (needOuter || Math.random() < 0.3)) parts.push(pick(outer));
    if (acc.length && Math.random() < 0.6) parts.push(pick(acc));

    const key = parts.map((p) => p.id).sort().join('-');
    if (seen.has(key)) continue;
    seen.add(key);
    result.push({ items: parts, score: colorScore(parts) + Math.random() });
  }

  return result
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((o, i) => ({ id: i + 1, items: o.items }));
}

module.exports = { generateOutfits };

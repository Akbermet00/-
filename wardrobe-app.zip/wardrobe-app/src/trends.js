// Поиск трендов и магазинов.
// С ключом SERPAPI_KEY — живой поиск Google (SerpAPI). Без ключа — запасной режим.

const HL = process.env.SEARCH_HL || 'ru';
const GL = process.env.SEARCH_GL || 'kg';
const KEY = () => process.env.SERPAPI_KEY;

const cache = new Map();
const TTL = 60 * 60 * 1000;

async function serp(params) {
  const url = new URL('https://serpapi.com/search.json');
  Object.entries({ hl: HL, gl: GL, ...params, api_key: KEY() }).forEach(([k, v]) =>
    url.searchParams.set(k, v)
  );
  const cacheKey = url.toString();
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.t < TTL) return hit.data;

  const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`SerpAPI вернул ${res.status}`);
  const data = await res.json();
  cache.set(cacheKey, { t: Date.now(), data });
  return data;
}

const FALLBACK_TRENDS = [
  { title: 'Оверсайз пальто и тренчи', snippet: 'Свободный крой, нейтральные цвета: бежевый, серый, графит.' },
  { title: 'Широкие джинсы и карго', snippet: 'Прямой и широкий силуэт вытесняет узкие модели.' },
  { title: 'Кожаные куртки и бомберы', snippet: 'Матовая кожа, укороченный и прямой крой.' },
  { title: 'Трикотаж и вязаные жилеты', snippet: 'Многослойность: жилет поверх рубашки или водолазки.' },
  { title: 'Кроссовки в ретро-стиле', snippet: 'Замша, сдержанные цвета, тонкая подошва.' },
  { title: 'Монохромные образы', snippet: 'Один цвет в разных оттенках и фактурах с головы до ног.' },
];

async function searchTrends(q) {
  const query = q && q.trim() ? q.trim() : 'модные тренды сезона одежда';
  const full = /тренд|мод/i.test(query) ? query : `модные тренды ${query}`;

  if (!KEY()) {
    const needle = (q || '').trim().toLowerCase();
    return {
      source: 'builtin',
      note: 'Ключ SERPAPI_KEY не задан — показан встроенный список. Добавьте ключ в .env для живого поиска.',
      results: FALLBACK_TRENDS.filter(
        (t) => !needle || `${t.title} ${t.snippet}`.toLowerCase().includes(needle)
      ),
      searchUrl: `https://www.google.com/search?q=${encodeURIComponent(full)}&hl=${HL}`,
    };
  }

  const data = await serp({ engine: 'google', q: full, num: 10 });
  const results = (data.organic_results || []).map((r) => ({
    title: r.title,
    snippet: r.snippet || '',
    link: r.link,
    source: r.displayed_link || r.source || '',
    thumbnail: r.thumbnail || null,
  }));
  return { source: 'serpapi', results };
}

async function searchShop(q) {
  const query = (q || '').trim();
  if (!query) return { source: 'none', results: [] };
  const enc = encodeURIComponent(query);

  if (!KEY()) {
    return {
      source: 'links',
      note: 'Ключ SERPAPI_KEY не задан — вместо карточек товаров даны ссылки на поиск в магазинах.',
      results: [
        { title: 'Google Покупки', source: 'google.com', link: `https://www.google.com/search?tbm=shop&q=${enc}&hl=${HL}` },
        { title: 'Wildberries', source: 'wildberries.ru', link: `https://www.wildberries.ru/catalog/0/search.aspx?search=${enc}` },
        { title: 'Lamoda', source: 'lamoda.ru', link: `https://www.lamoda.ru/catalogsearch/result/?q=${enc}` },
        { title: 'Ozon', source: 'ozon.ru', link: `https://www.ozon.ru/search/?text=${enc}` },
        { title: 'AliExpress', source: 'aliexpress.com', link: `https://aliexpress.com/wholesale?SearchText=${enc}` },
      ],
    };
  }

  const data = await serp({ engine: 'google_shopping', q: query });
  const results = (data.shopping_results || []).slice(0, 12).map((r) => ({
    title: r.title,
    price: r.price || '',
    source: r.source || '',
    link: r.product_link || r.link,
    thumbnail: r.thumbnail || null,
  }));
  return { source: 'serpapi', results };
}

module.exports = { searchTrends, searchShop };
